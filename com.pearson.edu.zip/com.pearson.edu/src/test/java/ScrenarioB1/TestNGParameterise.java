package ScrenarioB1;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNGParameterise {
	
	@BeforeTest
	public void beforeTest()
	{
		System.out.println(">>  Test started");
	}
	
	@DataProvider(name = "parameters")
	public Object[][] provideData()
	{
		Object[][] data = {
				{"A",1},
				{"B",2},
				{"C",3},
				{"D",4}
		};
		return data;
	}
	@Test(dataProvider = "parameters")
	public void getData(String s, int i)
	{
		System.out.println(">> Username : " + s + " Password : " + i);
	}
	
	@AfterTest
	public void afterTest()
	{
		System.out.println(">> Test finished");
	}

}
