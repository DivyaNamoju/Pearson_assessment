package com.pearson.testcases;

import org.testng.Assert;

/*
 * Author : Divya
 * Testing the SignIn Button of Pearson Home Page
 * 
 */
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.pearson.pages.HomePage;
import com.pearson.pages.SignInPage;
import com.pearson.testbase.TestBase;

/*
 * Testing only the Sign in button 
 */
public class HomePageTest extends TestBase{
	
	HomePage homePageObj;
	SignInPage signInObj;
	
	ExtentReports extent = new ExtentReports();
	ExtentSparkReporter spark = new ExtentSparkReporter("extentreports/extentreport_HomePageSigninButton.html");

	// Intial set up before the test
	@BeforeClass
	public void setUp()
	{
		TestBase.setUpBrowser();
		TestBase.openApp();
		homePageObj = new HomePage();
		signInObj = new SignInPage();
	}
	// Verifies the url
	@Test(priority = 1)
	public void verifyUrl() throws InterruptedException
	{
		extent.attachReporter(spark);
		ExtentTest test=extent.createTest("Verifying the Url").assignAuthor("Divya Namoju");
		String ExpectedUrl = "https://www.pearson.com/en-gb.html";
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(ExpectedUrl,actualUrl);
		test.info("Expected and Actual url are same");
		
		extent.flush();
	}
	// Verifies if clicking on sign in button will open the Sign In Dialog box
	@Test(priority = 2)
	public void verifySignInButton()
	{
		extent.attachReporter(spark);
		ExtentTest test=extent.createTest("Verifying the Sign in button on Home Page").assignAuthor("Divya Namoju");
		
		homePageObj.acceptCookies();
		homePageObj.closeDialogBox();
		if(homePageObj.signInButtonEnabled() && homePageObj.signInButtondisplayed())
		{
		homePageObj.clickSignIn();
		test.info("Sign in button is displayed and enabled");
		Assert.assertTrue(signInObj.dialogBoxAppears(), "SignIn Dialog Box didn't Open");
		}
		test.pass("Sign in button is functional and Sign in Dialog box appears");
		
		extent.flush();
	}
	// After class methods
	@AfterClass
	public void tearDown() throws InterruptedException
	{
		driver.close();
	}
}
