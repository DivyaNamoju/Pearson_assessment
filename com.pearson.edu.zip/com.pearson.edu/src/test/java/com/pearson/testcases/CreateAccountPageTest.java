package com.pearson.testcases;

/*
 * Testing the "Create Account" page with sample data
 */

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.pearson.pages.AccountCreatedDialogPage;
import com.pearson.pages.CreateAccountPage;
import com.pearson.pages.HomePage;
import com.pearson.pages.SignInPage;
import com.pearson.testbase.TestBase;
import com.pearson.utilities.TestUtil;

public class CreateAccountPageTest extends TestBase{
	
	HomePage homePageObj;
	SignInPage signInObj;
	CreateAccountPage createAccountObj;
	AccountCreatedDialogPage accountCreatedDialogObj;
	
	ExtentReports extent = new ExtentReports();
	ExtentSparkReporter spark = new ExtentSparkReporter("extentreports/extentreport_createAccount.html");
	
	//Intial set up before the test
	@BeforeTest
	public void setUp()
	{
		TestUtil.setUpBrowser();
		TestBase.openApp();
		homePageObj = new HomePage();
		signInObj = new SignInPage();
		createAccountObj = new CreateAccountPage();
		accountCreatedDialogObj = new AccountCreatedDialogPage();
	}
	// Checking if a new account is created on providing the appropriate values in the mandatory fields 
	@Test
	public void createAccounttest()
	{
		extent.attachReporter(spark);
		ExtentTest test = extent.createTest("Creating a new Account on Pearson Application").assignAuthor("Divya Namoju");
		
		
		homePageObj.acceptCookies();
		test.info("Accepted cookies");
		homePageObj.closeDialogBox();
		test.info("Closed the Ready Uni Dialog box");
		homePageObj.clickSignIn();	
		test.info("Clicked on sign In");
		signInObj.clickCreateAccount();
		test.info("Clicked on create Account Button");
		test.info("Creating a new account");
		createAccountObj.enterRole("Learner"); 
		test.info("Entered the role input");
		createAccountObj.enterFirstName("Divya"); 
		test.info("Entered the first name");
		createAccountObj.enterLastName("Namoju"); 
		test.info("Entered the last name");
		createAccountObj.enterUserName("divyatestautomation.practice@gmail.com"); 
		createAccountObj.enterPassword("Pearson@1234");
		test.info("Entered the username and password");
		createAccountObj.checkOnConsent();
		createAccountObj.checkOnMarketingOption();
		createAccountObj.checkThirdPartyMarketOption();
		test.info("Clicked on all the required check boxes");
		
		createAccountObj.clickCreateAccount();
		test.pass("Created account");
		String msg = accountCreatedDialogObj.getAccountCreatedTxt();
		test.pass(msg);
		
		extent.flush();
	}
	//After test methods
	@AfterTest
	public void tearDown()
	{
		driver.close();
	}
}
