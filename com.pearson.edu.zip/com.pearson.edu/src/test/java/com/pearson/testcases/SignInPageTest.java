package com.pearson.testcases;

/*
 * Testing the "Sign in" Page with a set of sample Test data
 */
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.pearson.pages.HomePage;
import com.pearson.pages.SignInPage;
import com.pearson.testbase.TestBase;
import com.pearson.utilities.TestUtil;

public class SignInPageTest extends TestBase{

	
	HomePage homePageObj;
	SignInPage signInObj;
	
	ExtentReports extent = new ExtentReports();
	ExtentSparkReporter spark = new ExtentSparkReporter("extentreports/extentreport_Signin.html");

	/* Intial setups before starting the test 
	 check for the browser name and URL value in config.properties file */
	@BeforeMethod
	public void setUp()
	{
		TestUtil.setUpBrowser();
		TestBase.openApp();
		homePageObj = new HomePage();
		signInObj = new SignInPage();
					
	}
	
	 // This test method will verify sign In functionality with different user credentials
	@Test(dataProvider = "UserLoginInfo")
	public void signIn(String uname, String pword)
	{
		extent.attachReporter(spark);
		ExtentTest test1 = extent.createTest("Sign In with Existing Account").assignAuthor("Divya Namoju");
		
		homePageObj.acceptCookies();
		test1.info("Accepted cookies");
		homePageObj.closeDialogBox();
		test1.info("Closed the Ready Uni Dialog box");
		homePageObj.clickSignIn();	
		test1.info("Clicked on sign In");
		
		signInObj.enterLoginDetails(uname,pword);
		test1.info("Entered username \"" + uname + "\" and password \"" + pword +"\"");
		signInObj.clickSubmit();
		test1.info("Clicked on Submit button");
		
		
		try {
		boolean alertmsg = signInObj.isAlertMessage();
		if(alertmsg) {
			test1.fail(signInObj.getAlertMessage()); 
			TestBase.takeScreenShots();
		}}
		catch(NoSuchElementException e){
			test1.pass("No alert message found");
		
			signInObj.clickuserNavButton();
			String msg = signInObj.checkUserAftersignIn();
			test1.pass("User Sign in successful");
			test1.pass("User Signed in  with the message ==> " + msg);
			signInObj.clickSignOut();
			test1.pass("User sign out successful");	}
		
		extent.flush();
	}
	// Data Provider for the Test
	@DataProvider(name = "UserLoginInfo")
	public Object[][] provideLoginInfo()
	{
		Object[][] data= {
				{"divya.namoju@gmail.com","Pearson@1234"},
				{"divya.otherwork@gmail.com","Pearson@1234"},
				{"divya.automationpractice@gmail.com","Pearson@1234"}
		};
		
		return data;
	//This method executes after every method execution
	}
	@AfterMethod
	public void tearDown()
	{
		driver.close();
	}

}
