package com.pearson.utilities;

// This class specifies the values which can be utilised and altered accordingly

import com.pearson.testbase.TestBase;

public class TestUtil extends TestBase{
	
	public static int IMPLICIT_WAIT=20;
	public static int EXPLICIT_WAIT=10;
	public static int PAGE_TIME_OUT=40;

}
