package com.pearson.testbase;

/*
 * This is base class which is inherited by all the other classes
 * This class contains methods to set up browser, get url and take screen shots
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pearson.utilities.TestUtil;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {

	public static WebDriver driver = null;
	public static Properties prop;
	public static TakesScreenshot ts;

	public TestBase()
	{
		String curDir= System.getProperty("user.dir");
		try
		{
			File file = new File(curDir + "/src/main/java/com/pearson/properties/config.properties");
			FileInputStream fip = new FileInputStream(file);
			prop = new Properties();
			prop.load(fip);

		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	// The browser value is extracted from the config.properties file
	public static void setUpBrowser()
	{
		String browserName = prop.getProperty("browser");
		if(browserName.equalsIgnoreCase("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}

		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(TestUtil.IMPLICIT_WAIT));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(TestUtil.PAGE_TIME_OUT));
		driver.manage().window().maximize();
	}
	// Url is extracted from the config.properties file
	public static void openApp()
	{
		String url = prop.getProperty("url");
		if(!url.equals(null))
		{
			driver.get(url);
		}
		else
		{
			driver.get("about:blank");
		}

	}
	// This method enables to capture a screenshot if required
	public static void takeScreenShots() 
	{
		ts = (TakesScreenshot) driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(src, new File("screenshot/error.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

}
