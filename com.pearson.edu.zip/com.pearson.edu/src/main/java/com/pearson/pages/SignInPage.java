package com.pearson.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.pearson.testbase.TestBase;

public class SignInPage extends TestBase{
	
	/* All the elements on SignIn page are located using different locators like id, css, className, xpath
	 * Sign in - Object/Elements Repository
	 */
	
	@FindBy(id="signin-dialog")
	public WebElement signInDialog;
	
	@FindBy(css="div[class*='subtitle1']")
	public WebElement headerTitle1;
	
	@FindBy(xpath="//div[contains(@class,'subtitle2')]/span")
	WebElement headerTitle2;
	
	@FindBy(xpath="//button[contains(text(),'Create an account')]")
	WebElement createAccountButton;
	
	@FindBy(xpath="//div[contains(@class,'body1')]")
	WebElement bodyText;
	
	@FindBy(xpath="//label[text()='Username']")
	WebElement usernameLabel;
	
	@FindBy(xpath="//label[text()='Password']")
	WebElement passwordLabel;
	
	@FindBy(id="ies-standard-signin-username")
	WebElement usernameInput;
	
	@FindBy(id="ies-standard-signin-password")
	WebElement passwordInput;
	
	@FindBy(xpath="//a[contains(text(),'Trouble')]")
	WebElement troubleSignInLink;
	
	@FindBy(xpath="//a[contains(text(),'Terms of Use')]")
	WebElement termsofuseLink;
	
	@FindBy(xpath="//a[contains(text(),'Privacy Policy')]")
	WebElement privacypolicyLink;
	
	@FindBy(id="ies-standard-signin-submit")
	WebElement submitSignInButton;
	
	@FindBy(xpath="(//*[local-name()='svg' and @class='MuiSvgIcon-root'])[1]")
	WebElement closeSignInSvg;
	
	@FindBy(xpath = "(//*[local-name()='svg' and @class='MuiSvgIcon-root'])[2]")
	WebElement passwordHideIconSvg;
	
	@FindBy(xpath = "(//div[@class='navbar-header'])[4]/button")
	WebElement userInfoButton;
	
	@FindBy(xpath = "(//div[@id='navbar-collapse-grid'])[4]//ul[@role='menu']//li/a[contains(text(),'Sign out')]")
	WebElement signOutLink;
	
	@FindBy(xpath = "//div[contains(@class,'Alert-message')]")
	WebElement alertMsg;
	
	
	public SignInPage()
	{
		super();
		PageFactory.initElements(driver, this);
	}
	
	//Checks whether the Sign in Dialog box appears - true/false
	public boolean dialogBoxAppears()
	{
		return signInDialog.isDisplayed();
	}

	// Get all text present on sign In page 
	public String getAllTexts(String s)
	{
		String textVal;
		if(s.equals("header1"))
			textVal =  headerTitle1.getText();
		else if(s.equals("header2"))
			textVal =  headerTitle2.getText();
		else if(s.equals("body"))
			textVal = bodyText.getText();
		else if(s.equals("usernametext"))
			textVal = usernameInput.getText();
		else if(s.equals("passwordtext"))
			textVal = passwordInput.getText();
		else
			textVal = "Please Enter following values" +"\n"+ "1.header1"+"\n"+"2.header2"+"\n"+"3.body"
						+"\n"+"4.usernametext"+"\n"+"5.passwordtext";
		
		return textVal;
	}
	//Enter the username and password values to the respective username and password fields
	public void enterLoginDetails(String uname, String pword)
	{
		usernameInput.clear();
		usernameInput.sendKeys(uname);
		passwordInput.clear();
		passwordInput.sendKeys(pword);
	}
	//click on submit button
	public void clickSubmit()
	{
		submitSignInButton.click();
	}
	// Click on create account link on Sign Dialog to create a new account
	public void clickCreateAccount()
	{
		createAccountButton.click();
	}
	//Click on User Navigation Info Button on Home Page 
	public void clickuserNavButton()
	{
		userInfoButton.click();
	}
	//Checking of the user name is displayed in User navigation Info
	public String checkUserAftersignIn()
	{	
		String listXpath = "(//div[@id='navbar-collapse-grid'])[4]//ul[@role='menu']/li";
		List<WebElement> list = driver.findElements(By.xpath(listXpath)); 
		String username = list.get(0).getText();
		
		return username;
	}
	//Click on signOut link in User Navigation Info
	public void clickSignOut()
	{
		signOutLink.click();
	}
	//Check whether the alert message appears if username or passowrd is incorrect
	public boolean isAlertMessage()
	{
		return alertMsg.isDisplayed();
	}
	//Get the alert message if the username or passowrd is entered incorrect
	public String getAlertMessage()
	{
		return alertMsg.getText();
	}
}
