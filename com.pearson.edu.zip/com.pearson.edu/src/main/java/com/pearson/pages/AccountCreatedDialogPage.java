package com.pearson.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.pearson.testbase.TestBase;

public class AccountCreatedDialogPage extends TestBase{
	
	// Elements Located from Account Created Dialog box after the successful account creation

	@FindBy(css="div[class*='subtitle1']")
	WebElement accountCreatedTxt;
	
	@FindBy(css="span[class*='body1']")
	WebElement accountCreatedBodyTxt;
	
	@FindBy(id="ies-standard-continue-confirmation")
	WebElement continueButton;
	
	public AccountCreatedDialogPage()
	{
		super();
		PageFactory.initElements(driver, this);
	}
	// Returns the message info from the dialog box
	public String getAccountCreatedTxt()
	{
		String header = accountCreatedTxt.getText();
		String body = accountCreatedBodyTxt.getText();
		return header.concat(body);
	}
	//click continue button on this Dialog box
	public void clickContinue()
	{
		continueButton.click();
	}
}
