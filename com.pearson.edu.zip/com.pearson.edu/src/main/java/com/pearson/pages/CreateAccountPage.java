package com.pearson.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.pearson.testbase.TestBase;

public class CreateAccountPage extends TestBase{
	
	// All the Elements on Create Account Page are located - Create Account Object Repository
	
	@FindBy(xpath="//div[@id='signin-dialog']/button")
	WebElement closeButton;
	
	@FindBy(css="div[class*='subtitle1']")
	WebElement headtitle1;
	
	@FindBy(xpath="//div[contains(@class,'subtitle2')]/span")
	WebElement headertitle2;
	
	@FindBy(xpath="//button[text()='Sign in']")
	WebElement signInButton;
	
	@FindBy(xpath = "//label[text()='Role']")
	WebElement roleLabel;
	
	@FindBy(id="roles-input")
	WebElement roleInput;
	
	@FindBy(css="button[class*='MuiAutocomplete-popupIndicator']")
	WebElement rolePopUpIndicatorButton;
	
	@FindBy(xpath="//button[@title='Clear']")
	WebElement clearroleInputButton;
	
	@FindBy(xpath="//label[text()='First name']")
	WebElement firstnameLabel;
	
	@FindBy(xpath = "//label[text()='Last name']")
	WebElement lastNameLabel;
	
	@FindBy(id="ies-field-name-firstname")
	WebElement firstNameInput;
	
	@FindBy(id="ies-field-name-lastname")
	WebElement lastNameInput;
	
	@FindBy(xpath = "//label[text()='Username']")
	WebElement usernameLabel;
	
	@FindBy(id="ies-standard-usernamecreateacct")
	WebElement userNameInput;
	
	@FindBy(xpath="(//label[text()='Username']/following::p)[1]")
	WebElement userNameHelpMsg;
	
	@FindBy(xpath="//label[text()='Password']")
	WebElement passwordLabel;
	
	@FindBy(id="ies-standard-adornment-password-createacct")
	WebElement passwordInput;
	
	@FindBy(id="ies-password-helper-text")
	WebElement passwordHelpMsg;
	
	@FindBy(xpath="//input[@id='ies-standard-adornment-password-createacct']/following::button[1]")
	WebElement passwordIconButton;
	
	@FindBy(xpath="//input[@name='consent']")
	WebElement consentCheckBox;
	
	@FindBy(xpath="//a[text()='Terms of Use']")
	WebElement termsofuseLink;
	
	@FindBy(xpath="//a[text()='Privacy Policy']")
	WebElement privacypolicyLink;
	
	@FindBy(xpath="//input[@name='marketingOptOut']")
	WebElement marketingoutputCheckBox;
	
	@FindBy(xpath="//input[@name='marketingOptOut']/following::p[1]")
	WebElement marketingoutputMsg;
	
	@FindBy(xpath="//input[@name='thirdPartyMarketingOptIn']")
	WebElement thirdpartyCheckBox;
	
	@FindBy(xpath="//input[@name='thirdPartyMarketingOptIn']/following::p")
	WebElement thirdpartyMsg;
	
	@FindBy(id="create-account-submit-btn")
	WebElement createAccountButton;
	
	public CreateAccountPage()
	{
		super();
		PageFactory.initElements(driver, this);
	}
	// Enter a role input value 
	public void enterRole(String s)
	{
		roleInput.click();
		roleInput.sendKeys(s+Keys.ENTER);
	}
	// Enter a first name input value
	public void enterFirstName(String s)
	{
		firstNameInput.clear();
		firstNameInput.sendKeys(s);
	}
	// Enter last name input value
	public void enterLastName(String s)
	{
		lastNameInput.clear();
		lastNameInput.sendKeys(s);
	}
	// Enter user name input value
	public void enterUserName(String s)
	{
		userNameInput.clear();
		userNameInput.sendKeys(s);
	}
	// Enter password value
	public void enterPassword(String s)
	{
		passwordInput.clear();
		passwordInput.sendKeys(s);
	}
	// Click on consent check box
	public void checkOnConsent()
	{
		consentCheckBox.click();
	}
	//Click on Marketing option check box
	public void checkOnMarketingOption()
	{
		marketingoutputCheckBox.click();
	}
	//Click on third pary market option check box
	public void checkThirdPartyMarketOption()
	{
		thirdpartyCheckBox.click();
	}
	//Click on create account check box
	public void clickCreateAccount()
	{
		createAccountButton.click();
	}
}

