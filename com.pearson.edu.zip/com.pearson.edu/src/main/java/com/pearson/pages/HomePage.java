package com.pearson.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.pearson.testbase.TestBase;

public class HomePage extends TestBase{
	
	// Elements Located pertinent to SignIn to the Pearson Application
	
	@FindBy(css="button#onetrust-accept-btn-handler")
	public WebElement yesCookiesButton;
	
	@FindBy(css="button#onetrust-pc-btn-handler")
	public WebElement noCookiesButton;
	
	@FindBy(id="submit_button")
	public WebElement submitDialogButton;
	
	@FindBy(className = "bcToasterCloseButton")
	public WebElement closeDialogButton;
	
	@FindBy(className = "usernav-signin-button")
	public WebElement signInButton;
	
	@FindBy(css="div[class*='onetrust-pc-dark-filter']")
	WebElement shadow;
	
	@FindBy(css="div.ot-sdk-container")
	WebElement cookieContainer;
		
	public HomePage()
	{
		super();
		PageFactory.initElements(driver, this);
	}
	// Accepting the cookies
	public void acceptCookies()
	{
		yesCookiesButton.click();
	}
	// Closes the Ready uni Dialog box that appears on the Home page
	public void closeDialogBox()
	{
		closeDialogButton.click();
	}
	//Click on Sign In Button
	public void clickSignIn()
	{
		signInButton.click();
	}
	//Checks if Sign In button is displayed on HomePage
	public boolean signInButtonEnabled()
	{
		return signInButton.isDisplayed();
	}
	//Checks if the Sign In Button is enabled on HomePage
	public boolean signInButtondisplayed()
	{
		return signInButton.isEnabled();
	}
	
}
